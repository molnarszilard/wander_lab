class LogLevel:
    Silent = 0
    Errors = 1
    Debug_Verbose = 2
