(The Sphero SDK/lib will be symlinked here.)

See instructions here: https://github.com/markusk/rvr

